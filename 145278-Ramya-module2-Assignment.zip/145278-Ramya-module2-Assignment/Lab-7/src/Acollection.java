
public class Acollection implements Comparable<Acollection>{
	String product;

	public Acollection(String product) {
		super();
		this.product = product;
	}

	@Override
	public int compareTo(Acollection arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
