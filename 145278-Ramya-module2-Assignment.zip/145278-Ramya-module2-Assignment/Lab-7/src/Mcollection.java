import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Mcollection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   List<String> sr=new ArrayList<>();
   sr.add("book");
   sr.add("pen");
   sr.add("pencil");
   sr.add("anu");
   Collections.sort(sr);
  sr.forEach(System.out::println);
	}

}
