

import java.util.Arrays;
import java.util.Scanner;

public class Product {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
        System.out.print("Enter number of names you want to enter:");
      int  n = s.nextInt();
        String names[] = new String[n];
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter all the names:");
        for(int i=0;i<n;i++)
        {
        	names[i]=sc.next();
        }
        System.out.println("The names are");
        for(int i=0;i<n;i++)
        {
        	 Arrays.sort(names);
        	System.out.println(names[i]);
        }
       
	}

}
