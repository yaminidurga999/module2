package com.cg.mobapp.dao;

import com.cg.mobapp.dto.PurchaseDetails;
import com.cg.mobapp.exception.MobileException;

public interface PurchaseDao
{
public int addPurchaseDetails(PurchaseDetails purchase) throws MobileException;
}
