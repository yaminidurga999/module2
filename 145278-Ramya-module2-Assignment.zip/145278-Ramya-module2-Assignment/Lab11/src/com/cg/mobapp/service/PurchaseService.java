package com.cg.mobapp.service;

import com.cg.mobapp.dto.PurchaseDetails;
import com.cg.mobapp.exception.MobileException;

public interface PurchaseService {
	public int addPurchaseDetails(PurchaseDetails purchase) throws MobileException;
}
