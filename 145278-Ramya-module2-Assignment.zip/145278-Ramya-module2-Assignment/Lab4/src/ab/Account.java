package ab;

public class Account {
    int accountNo;
    String accountHolderName;
    double balance;
   // double interestRate;
    String accountType;
    public Account(int accno,double balance){
    	accountNo=accno;
    	this.balance=balance;
    }
    public Account(int accno,double balance,String name){
    	this(accno,balance);
    	name=accountHolderName;
    }
	public int getAccNo() {
		return accountNo;
	}
	public void setAccNo(int accNo) {
		this.accountNo = accNo;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	//public double getInterestRate() {
	//	return interestRate;
	//}
	//public void setInterestRate(double interestRate) {
	////	this.interestRate = interestRate;
	//}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
    public void withdraw(double amount){
    	if(balance<amount){
    		System.out.println("Insufficient Balance");
    	}
    	else{
    		balance=balance-amount;
    		System.out.println(amount +"Rs debited from your Account: "+accountNo);
    	}
    	
    }
    public void deposit(double amount){
    	balance=balance+amount;
    	System.out.println(amount +"Rs credited to your Account: "+accountNo);
    }
    public void printAccountDetails(double d){
    	System.out.println("accNo: "+accountNo);
    	System.out.println("Account Holder Name: "+accountHolderName);
    	System.out.println("Balance: "+balance);
    }
	@Override
	public String toString() {
		return "Account [accNo=" + accountNo + ", accountHolderName="
				+ accountHolderName + ", balance=" + balance + "]";
	}
    
    
    
}
