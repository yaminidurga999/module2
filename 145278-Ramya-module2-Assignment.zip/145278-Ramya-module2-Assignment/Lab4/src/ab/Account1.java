package ab;

public class Account1 extends Person{
  long accNum;
  double balance;
  String accHolder;
  Account1(){
}
public Account1(long accNum, double balance, String accHolder) {
	super();
	this.accNum = accNum;
	this.balance = balance;
	this.accHolder = accHolder;
}
public long getAccNum() {
	return accNum;
}
public void setAccNum(long accNum) {
	this.accNum = accNum;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public String getAccHolder() {
	return accHolder;
}
public void setAccHolder(String accHolder) {
	this.accHolder = accHolder;
}
public void deposit(double amount){
	this.balance+=amount;
	System.out.println("Rs."+amount+" credited to your account: "+this.accNum);
	System.out.println("Updated balance: "+this.balance);
}
public void withdraw(double amount){
	this.balance-=amount;
	System.out.println("Rs."+amount+" debited from  your account: "+this.accNum);
	System.out.println("Updated balance: "+this.balance);
}
public void display(){
	
	System.out.println("Account number:  "+this.accNum);
	System.out.println("Acount holder name: "+this.accHolder);
	System.out.println("Balance: "+this.balance);
}
}
