package ab;

public class CurrentAccount extends Account{
     public CurrentAccount(int accno, double balance) {
		super(accno, balance);
		// TODO Auto-generated constructor stub
	}
	double overDraftlimit=1000000;
     @Override
     public void withdraw(double amount){
    	 if(amount>overDraftlimit){
    		 System.out.println("Over draft limit reached.");
    	 }
    	 else{
    		 result();
    		 super.withdraw(amount);}
    		 
    	 }
    	 private boolean result(){
    		 return true;
    	 }
     
}
