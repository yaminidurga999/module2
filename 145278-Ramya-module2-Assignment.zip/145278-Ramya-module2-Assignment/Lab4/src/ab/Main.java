package ab;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Person p1=new Person();
      Person p2=new Person();
      p1.setName("smith");
      p2.setName("kathy");
      Person a1=new Account1(1000,2000,p1.name);
      Person a2=new Account1(1001,3000,p1.name);
      ((Account1)a1).deposit(2000);
      ((Account1)a2).withdraw(2000);
      ((Account1)a1).display();
      ((Account1)a2).display();
	}

}
