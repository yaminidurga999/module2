package ab;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Account acc1=new Account(0,0);
       acc1.setAccNo(34621);
       acc1.setAccountHolderName("ramya");
       acc1.setAccountType("Savings");
       acc1.setBalance(2340);
       //acc1.setInterestRate(34621);
       acc1.printAccountDetails(6.5);
       acc1.withdraw(6789);
	}

}
