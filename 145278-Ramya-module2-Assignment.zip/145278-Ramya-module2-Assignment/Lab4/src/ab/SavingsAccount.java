package ab;

public class SavingsAccount extends Account{
          public SavingsAccount(int accno, double balance) {
		super(accno, balance);
		// TODO Auto-generated constructor stub
	}
		final double minimumBalance=500;
          @Override
          public void withdraw(double amount){
        	  if(this.balance<minimumBalance)
        		  System.out.println("There is no minimum balance");
        	  else
        		  super.withdraw(amount);
          }
}
