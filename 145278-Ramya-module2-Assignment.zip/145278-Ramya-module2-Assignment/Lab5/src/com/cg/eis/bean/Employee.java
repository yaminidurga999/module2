package com.cg.eis.bean;

public class Employee {
	public int id;
	public String name;
	public Float salary;
	public String designation;

	public Employee(int id, String name, float salary, String designation) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary
				+ ", designation=" + designation + "]";
	}
}
 