package com.cg.eis.pl;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmployeeService;
public class EmployeeInsuranceSchemeApp {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner sc=new Scanner(System.in);
		System.out.println("Pls Enter Employee Id: ");
		int id=sc.nextInt();
		System.out.println("Pls Enter Employee Name: ");
		String name=sc.next();
		System.out.println("Pls Enter Employee Salary: ");
		float salary=sc.nextFloat();
		sc.nextLine();
		System.out.println("Pls Enter Employee Designation: ");
		String designation=sc.nextLine();		
		Employee e=new Employee(id, name, salary, designation);
		
		IEmployeeService emps=new EmployeeServiceImpl();
		emps.findScheme(e);
		System.out.println(emps.findScheme(e));
	}

}
