package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements IEmployeeService {

	public String findScheme(Employee emp) {
		// TODO Auto-generated method stub
		
	if((emp.salary>=5000 && emp.salary<20000)&&(emp.designation.equals("System Associate")) )
	{
	return "Scheme C";
	}
	else if((emp.salary>=20000 && emp.salary<40000)&&(emp.designation.equals("Programmer")) )
	{
	return "Scheme B";
	}
	else if((emp.salary>=40000)&&(emp.designation.equals("Manager")) )
	{
	return "Scheme A";
	}
	else if ((emp.salary<5000)&&(emp.designation.equals("Clerk")) )
	{
	return "No Scheme";
	}
	else{
		return "Pls enter valid details";
	}
	
	}

	

}
