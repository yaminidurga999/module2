package com.cg.mobapp.dao;

import com.cg.exception.MobileException;
import com.cg.mobapp.dto.PurchaseDetails;

public interface PurchaseDao {
	public int addPurchaseDetails(PurchaseDetails purchase) throws MobileException;
	

}
