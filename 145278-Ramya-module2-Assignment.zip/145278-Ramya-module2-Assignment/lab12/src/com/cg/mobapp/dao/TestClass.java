package com.cg.mobapp.dao;



import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.cg.exception.MobileException;
import com.cg.mobapp.dto.Mobile;

public class TestClass {
	
	@Test
	public void testAddMethod(){
		MobileDao dao=new MobileDaoimpl();
 
		Mobile mobile =new Mobile();
		mobile.setMobileId(456);
		mobile.setMobileName("Afdgfdgf");
		mobile.setPrice(57899);
		mobile.setQuantity(5);
		try {
			int res= dao.addMobile(mobile);
			Assert.assertTrue(res!=0);
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 
	}
	@Test
	public void testSelectMethod(){
 
			MobileDao dao=new MobileDaoimpl();
			try {
				List<Mobile> list=dao.getMobileList();
				Assert.assertTrue(list.size() >0 );
				} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
 
	public void testUpdateMethod(){
		MobileDao dao=new MobileDaoimpl();
		Mobile mob =new Mobile();
		mob.setMobileId(459);
		mob.setQuantity(8);
		try {
			int res= dao.updateMobile(mob);
			Assert.assertTrue(res!=0);
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 
	}

}
