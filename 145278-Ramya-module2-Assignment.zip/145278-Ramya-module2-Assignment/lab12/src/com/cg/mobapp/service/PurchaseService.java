package com.cg.mobapp.service;
 
import com.cg.exception.MobileException;
import com.cg.mobapp.dto.PurchaseDetails;
 
public interface PurchaseService {
 
	public int addPurchaseDetails(PurchaseDetails purchase) throws  MobileException;
}