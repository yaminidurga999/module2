package com.cg.mobapp.service;
 
import com.cg.exception.MobileException;
import com.cg.mobapp.dao.PurchaseDao;
import com.cg.mobapp.dao.PurchaseDaoImpl;
import com.cg.mobapp.dto.PurchaseDetails;
 
public class PurchaseServiceImpl implements PurchaseService{
 
	PurchaseDao dao;
	public PurchaseServiceImpl() {
		dao= new PurchaseDaoImpl();
 
	}
	@Override
	public int addPurchaseDetails(PurchaseDetails purchase)
			throws MobileException {
		return dao.addPurchaseDetails(purchase);
	}
 
}
