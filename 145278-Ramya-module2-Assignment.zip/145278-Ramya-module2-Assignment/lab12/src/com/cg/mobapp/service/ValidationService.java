package com.cg.mobapp.service;
 
public interface ValidationService {
 
	public boolean validateCustomerName(String name);
	public boolean validateMailId(String mailid);
	public boolean validateMobileNo(String mobno);
	public boolean validateMobileId(String id);
}