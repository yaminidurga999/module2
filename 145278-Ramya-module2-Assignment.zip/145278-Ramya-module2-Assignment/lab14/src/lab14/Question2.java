

package lab14;

import java.util.Scanner;

public class Question2 {
	public static String main(String[] args) {
	String str;
	Scanner sc=new Scanner(System.in);
	str=sc.next();
	System.out.println("Enter the string u want to add spaces");
	StringBuilder result = new StringBuilder();

	for(int i = 0 ; i < str.length(); i++)
	{
	   result = result.append(str.charAt(i));
	   if(i == str.length()-1)
	      break;
	   result = result.append(' ');
	}

	return str.toString();
}
}
