package Question1;

import java.util.Scanner;

public class Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Employee e= new Employee(sc.next(),sc.next(),sc.next().charAt(0),sc.nextInt(),sc.nextFloat());
		e.display();
	}


}
