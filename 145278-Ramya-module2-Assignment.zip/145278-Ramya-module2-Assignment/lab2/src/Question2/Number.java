package Question2;

import java.util.Scanner;

public class Number {
	public Number()
	{
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int n;
		System.out.println("Enter a No:");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		
		if(n>0)
			System.out.println("Postive Number");
		else
			System.out.println("Negative Number");
	}

}
