package Question3;

public class PersonDetails {
	private String fname;
	private String lname;
	private char gender;
	public PersonDetails(String fname, String lname, char gender) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.gender = gender;
	}
	
	public PersonDetails(){
		super();
	}
	
	
	public String getFname()
	{
		return fname;
	}
	public void setFname(String fname)
	{
		this.fname = fname;
	}
	public String getLname()
	{
		return fname;
	}
	public void setLname(String lname)
	{
		this.lname = lname;
	}
	public char getGender()
	{
		return gender;
	}
	public void setGender(char gender){
		this.gender = gender;
	}

}
