package Question3;

import java.util.Scanner;

public class PersonMain {
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		PersonDetails d1=new PersonDetails();
		d1.setFname(sc.next());
		System.out.println(d1.getFname());
		d1.setLname(sc.next());
		System.out.println(d1.getLname());
		d1.setGender(sc.next().charAt(0));
		System.out.println(d1.getGender());
		
	}

}
