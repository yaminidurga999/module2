package Question4;

public class Phno {
	String fname;
	String lname;
	char gender;
	int age;
	int phoneno;
	float weight;
	public Phno(String fname, String lname, char gender,int age, int phoneno,
			float weight)
	{
		super();
		this.fname = fname;
		this.lname = lname;
		this.gender = gender;
		this.phoneno=phoneno;
		this.age = age;
		this.weight = weight;
	}
	@Override
	public String toString() {
		return "Usingconsub [fname=" + fname + ", lname=" + lname + ", gender="
				+ gender + ", age=" + age + ", phoneno=" + phoneno
				+ ", weight=" + weight + "]";
	}

}
