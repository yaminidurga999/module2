package Question4;

import java.util.Scanner;

public class Phonenum {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Phno r=new Phno(sc.next(),sc.next(),sc.next().charAt(0),sc.nextInt(),sc.nextInt(),sc.nextFloat());
		System.out.println(r);
sc.close();
	}

}
