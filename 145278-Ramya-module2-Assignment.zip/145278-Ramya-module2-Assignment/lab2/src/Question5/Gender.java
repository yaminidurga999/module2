package Question5;

public enum Gender {
	M,F;
}
