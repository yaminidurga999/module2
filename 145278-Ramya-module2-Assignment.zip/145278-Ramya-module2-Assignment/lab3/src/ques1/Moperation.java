package ques1;


public class Moperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Soperation so=new Soperation ();
		so.display();
	}

}
