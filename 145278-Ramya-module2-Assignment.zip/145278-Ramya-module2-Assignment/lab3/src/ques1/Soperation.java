package ques1;

import java.util.Scanner;

public class Soperation 
{
	void display(){
		
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the string");
	String s=sc.next();
	String n=sc.next();
System.out.println("enter the task");
String t=sc.next();
	
	switch(t)
	{
	case "con":
		System.out.println("new string string is " +s.concat(s));
		break;
	case "odd" :
		for(int i=0;i<n.length();i++)
		{
			char ch=n.charAt(i);
			if(i%2==0){
				System.out.println(Character.toLowerCase(ch));
			}
			else
			{
				System.out.println(Character.toUpperCase(ch));
			}
		}
		System.out.println();
	case "replace":
		for(int i=0;i<n.length();i++){
			char ch=n.charAt(i);
			if(i%2==0){
				System.out.println((ch));
			}
			else
			{
				System.out.println("#");
			}
			
		}
		System.out.println();
	case "dup" :
		String output="";
		for(int i=0;i<n.length();i++){
			
			char ch=s.charAt(i);
			if(ch!=' ')
				{
					
				output=output+ch;
				n=n.replace(ch, ' ');
				
				}
		
			
		}
		
		System.out.println(output);
	}
	
	
}



}

