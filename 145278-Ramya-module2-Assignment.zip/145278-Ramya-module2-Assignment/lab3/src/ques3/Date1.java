package ques3;

import java.util.Date;



public class Date1 {
	public static void dateMethod(Date start,Date end)
	{
		
	
	}
}
