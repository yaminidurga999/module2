package ques3;

import java.util.Calendar;

public class Mdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calendar start=Calendar.getInstance();
		start.set(1996,05,25);
		Calendar end=Calendar.getInstance();
		long diff=end.getTimeInMillis()-start.getTimeInMillis();
		int days=(int)(diff/(24*60*60*1000));
		int year=(int)(days/365);
		System.out.println(days);
		System.out.println(year);
	}

}
