package ques4;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class Date1 {
	public static void dateMethod(LocalDate start)
	{
		LocalDate end=LocalDate.now();
		Period period=start.until(end);
		System.out.println("Days: "+period.get(ChronoUnit.DAYS));
		System.out.println("Months: "+period.get(ChronoUnit.MONTHS));
		System.out.println("Years: "+period.get(ChronoUnit.YEARS));
		
	}
}
