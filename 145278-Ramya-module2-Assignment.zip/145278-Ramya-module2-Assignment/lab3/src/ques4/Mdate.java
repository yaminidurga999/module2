package ques4;

import java.time.LocalDate;
import java.time.Month;

public class Mdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate start=LocalDate.of(1995, Month.SEPTEMBER, 25);
		
	}

	


}
