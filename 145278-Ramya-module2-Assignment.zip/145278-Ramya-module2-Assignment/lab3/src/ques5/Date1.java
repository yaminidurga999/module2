package ques5;

public class Date1 {
	public static void calcWarranty()
	{
		
	}
}
