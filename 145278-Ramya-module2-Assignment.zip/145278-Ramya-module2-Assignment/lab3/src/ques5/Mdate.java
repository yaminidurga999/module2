package ques5;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class Mdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate purchaseDate=LocalDate.of(2005,Month.APRIL,29);
		Period period=Period.of(10, 6, 0);
		LocalDate expiryDate=purchaseDate.plusMonths(period.getMonths());
		expiryDate=purchaseDate.plusYears(period.getYears());
		System.out.println("Expiry date: "+expiryDate);

	}

}
