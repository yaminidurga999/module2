package ques6;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Mclass {
	public static void main(String[] args) {
	

	zoneMethod(ZoneId.of("Europe/London"));
	zoneMethod(ZoneId.of("Asia/Tokyo"));
	zoneMethod(ZoneId.of("US/Pacific"));
	zoneMethod(ZoneId.of("Africa/Cairo"));
	zoneMethod(ZoneId.of("Australia/Sydney"));
}

	private static void zoneMethod(ZoneId id) {
		// TODO Auto-generated method stub
		System.out.println(ZonedDateTime.now(id));
	}
}
