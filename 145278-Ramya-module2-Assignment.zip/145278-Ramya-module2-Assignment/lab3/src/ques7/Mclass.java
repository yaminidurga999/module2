package ques7;

import java.time.LocalDate;

public class Mclass {

	 
		static void displayDetail(Person p)
		{
			System.out.println("Person Details");
			System.out.println("---------------------");
			System.out.println("Full Name: "+p.getFullName(p.firstName,p.lastName));
			System.out.println("Gender: "+p.getGender());
			System.out.println("Age: "+p.calcAge());

		}
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Person p=new Person("Apurwa","Ghosh",'F',LocalDate.of(1996, 05, 04));
			displayDetail(p);
		}

}
