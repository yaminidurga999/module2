package lab6;

public class Age {
int age;
public void validateage(int age) throws AgeNotFound
{
	try
	{
		if(age>15)
			throw new AgeNotFound("Please enter the valid age");
		else
			System.out.println(age);
	}catch(Exception e)
	{
		e.printStackTrace();
	}
}
}
