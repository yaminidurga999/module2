package lab6;

public class AgeNotFound extends Exception{
public AgeNotFound(String msg)
{
	super(msg);
}
}
