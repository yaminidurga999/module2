package lab6;

public class EmployeeNotFound  extends Exception{
	public EmployeeNotFound(String msg)
	{
		super(msg);
	}

}
