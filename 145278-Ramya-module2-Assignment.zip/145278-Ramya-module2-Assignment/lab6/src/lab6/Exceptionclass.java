package lab6;

public class Exceptionclass {
	String fname;
	String lname;
	
    public void validate (String fname,String lname) throws EmployeeNotFound
    {
    	try
    	{
    		//System.out.println(fname.equals(null));
    	if(fname.equals("")|lname.equals(""))
    		//if(fname==""||lname=="")
    	{
    		throw new EmployeeNotFound("Blank");
    	} else
    	{
    		System.out.println(fname);
    		System.out.println(lname);
    	}
    	}catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    		
    }
}

