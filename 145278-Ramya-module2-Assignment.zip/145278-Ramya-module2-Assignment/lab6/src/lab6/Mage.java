package lab6;

import java.util.Scanner;

public class Mage {

	public static void main(String[] args) throws AgeNotFound {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the age");
int age=s.nextInt();
Age a=new Age();
a.validateage(age);

	}

}
