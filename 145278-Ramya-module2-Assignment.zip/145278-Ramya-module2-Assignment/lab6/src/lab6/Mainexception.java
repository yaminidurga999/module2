package lab6;

import java.util.Scanner;

public class Mainexception {

	public static void main(String[] args) throws EmployeeNotFound {
		// TODO Auto-generated method stub
		Exceptionclass emp=new Exceptionclass();
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the firstname");
		String fname=s.nextLine();
		System.out.println("Enter the last name");
		String lname=s.nextLine();
		emp.validate(fname,lname);
	}

}
