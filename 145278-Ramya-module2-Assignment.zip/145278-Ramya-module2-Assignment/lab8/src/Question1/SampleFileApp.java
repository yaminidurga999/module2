package Question1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

public class SampleFileApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Reader fi=null;
		BufferedReader br= null;
		Writer writer = null;
		BufferedWriter bufWeriter = null;
		String line=null;
		StringBuffer sbuf=null;
		try{
			fi=new FileReader("C:\\Users\\learning\\TakeCare Clinic Software Application_139410_Nikhil_M2\\lab8\\src\\Question1\\Input.txt");
			br=new BufferedReader(fi);
			writer = new FileWriter("C:\\Users\\learning\\TakeCare Clinic Software Application_139410_Nikhil_M2\\lab8\\src\\Question1\\Output.txt");
			bufWeriter= new BufferedWriter(writer);
			
		while((line=br.readLine())!=null){
			sbuf=new StringBuffer(line);
			bufWeriter.write(sbuf.reverse().toString());
			bufWeriter.write("\n");
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			try {
				bufWeriter.close();
				writer.close();
				br.close();
				fi.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
