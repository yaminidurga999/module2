package Question2;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class SimpleScApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=null;
		FileReader fi=null;
		String []a=null;
		String line=null;
		try {
			fi=new FileReader("C:\\Users\\learning\\TakeCare Clinic Software Application_139410_Nikhil_M2\\lab8\\src\\Question2\\numbers.txt");
			sc=new Scanner(fi);
			line=sc.nextLine();
			System.out.println(line);
			a=line.split(",");
			for(int i=0; i<a.length;i++){
				if(Integer.parseInt(a[i]) !=0 && Integer.parseInt(a[i])%2==0 ){
					System.out.println(a[i]);
				}
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			sc.close();
			try {
				fi.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
