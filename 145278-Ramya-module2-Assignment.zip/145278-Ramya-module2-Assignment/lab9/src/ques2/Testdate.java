package ques2;

import static org.junit.Assert.*;

import org.junit.Test;

public class Testdate {
	
	@Test
	public void testSetDay() {
		System.out.println("test of set day");
		Date date=new Date(12,01,1987);
		date.setDay(20);
		assertEquals(20,date.intDay);
		
	}
	
	@Test
	public void testSetMonth() {
		
		System.out.println("test of set month");
		Date date=new Date(12,01,1987);
		date.setMonth(10);
		assertEquals(10,date.intMonth);
		
	}
	
	@Test
	public void testSetYear() {
		
		System.out.println("test of set year");
		Date date=new Date(12,01,1987);
		date.setYear(1996);
		assertEquals(1996,date.intYear);
		
	}
	@Test
	public void testGetDay() {
		
		System.out.println("test of get day");
		Date date=new Date(12,01,1987);
		assertEquals(12,date.getDay());
		
	}	
	
	
	@Test
	public void testGetMonth() {
		
		System.out.println("test of get month");
		Date date=new Date(12,01,1987);
		assertEquals(1,date.getMonth());
		
	}	
	
	
	@Test
	public void testGetYear() {
		
		System.out.println("test of get month");
		Date date=new Date(12,01,1987);
		assertEquals(1987,date.getYear());
	}
	
	@Test
	public void testToString() {
		System.out.println("test of to string");
		Date date=new Date(12,01,1987);
		assertEquals("Date is 12/1/1987",date.toString());
		
	}


}
